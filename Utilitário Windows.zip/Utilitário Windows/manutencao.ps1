﻿# ===========================
#  UTILITÁRIO DE MANUTENÇÃO
# ===========================

function Pause {
    Write-Host ""
    Read-Host "Pressione ENTER para continuar..."
}

# Verifica se está como administrador
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Este script precisa ser executado como Administrador!" -ForegroundColor Red
    Pause
    exit
}

# ===========================
#      OTIMIZAÇÃO SISTEMA
# ===========================

function OtimizacaoSistema {

    Write-Host "`n=== OTIMIZAÇÃO DO SISTEMA ===" -ForegroundColor Cyan

    # Limpeza de Disco automática
    Write-Host "Executando limpeza de disco..."
    cleanmgr /sagerun:1

    # DISM
    Write-Host "Limpando componentes do Windows..."
    DISM /Online /Cleanup-Image /StartComponentCleanup /Quiet

    # SFC
    Write-Host "Verificando integridade do sistema..."
    sfc /scannow

    # Temporários do Windows e usuário
    Write-Host "Removendo arquivos temporários..."
    Get-ChildItem "C:\Windows\Temp" -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
    Get-ChildItem "$env:TEMP"       -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue

    # Lixeira
    Write-Host "Esvaziando a Lixeira..."
    Clear-RecycleBin -Force -ErrorAction SilentlyContinue

    Write-Host "`nOtimização do sistema concluída!" -ForegroundColor Green
    Pause
}

# ===========================
#    OTIMIZAÇÃO DE REDE
# ===========================

function OtimizacaoRede {

    Write-Host "`n=== OTIMIZAÇÃO DE REDE ===" -ForegroundColor Cyan

    ipconfig /release
    ipconfig /renew

    ipconfig /flushdns

    netsh winsock reset
    netsh int ip reset

    Write-Host "`nOtimização de rede concluída!" -ForegroundColor Green
    Pause
}

# ===========================
# OTIMIZAÇÃO DE INICIALIZAÇÃO
# ===========================

function OtimizacaoInicializacao {

    Write-Host "`n=== OTIMIZAÇÃO DA INICIALIZAÇÃO ===" -ForegroundColor Cyan

    # ----- 1. Limpando Prefetch -----
    Write-Host "Limpando Prefetch..."
    Remove-Item "C:\Windows\Prefetch\*" -Force -ErrorAction SilentlyContinue

    # ----- 2. Ativando Fast Startup -----
    Write-Host "Ativando inicialização rápida (Fast Startup)..."
    powercfg /hibernate on
    powercfg /h /type reduced

    # ----- 3. Desabilitando tarefas pouco úteis -----
    Write-Host "Desabilitando tarefas não essenciais..."

    $tarefas = @(
        "Microsoft\Windows\Maps\MapsUpdateTask",
        "Microsoft\Windows\RetailDemo\CleanupOfflineContent",
        "Microsoft\Windows\Application Experience\ProgramDataUpdater",
        "Microsoft\Windows\Application Experience\StartupAppTask"
    )

    foreach ($t in $tarefas) {
        Disable-ScheduledTask -TaskPath ($t -replace '[^\\]+$', '\') -TaskName ($t.Split('\')[-1]) -ErrorAction SilentlyContinue
    }

    # ----- 4. Desabilitando alguns serviços desnecessários -----
    Write-Host "Ajustando serviços seguros..."

    $servicos = @(
        "DiagTrack",         # Telemetria
        "RemoteRegistry",    # Registro Remoto
        "RetailDemo"         # Modo demonstração
    )

    foreach ($s in $servicos) {
        if (Get-Service -Name $s -ErrorAction SilentlyContinue) {
            Set-Service -Name $s -StartupType Manual
        }
    }

    # ----- 5. Limpando cache de Miniaturas -----
    Write-Host "Limpando cache de miniaturas..."
    Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache*" -Force -ErrorAction SilentlyContinue

    Write-Host "`nOtimização da inicialização concluída!" -ForegroundColor Green
    Pause
}

# ===========================
#           MENU
# ===========================

while ($true) {
    Clear-Host

    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host "           UTILITÁRIO DE OTIMIZAÇÕES DO WINDOWS" -ForegroundColor Yellow
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host "        Ferramenta automatizada para melhorar desempenho," -ForegroundColor White
    Write-Host "         limpar arquivos desnecessários e ajustar rede." -ForegroundColor White
    Write-Host "                                                          "
    Write-Host "        Desenvolvimento: Samir Calixto" -ForegroundColor DarkCyan
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "1 - Otimização do Sistema"
    Write-Host "2 - Otimização de Conexão"
    Write-Host "3 - Otimização da Inicialização"
    Write-Host "0 - Sair"
    Write-Host "==============================================================" -ForegroundColor Cyan
    
    $op = Read-Host "Escolha uma opção"

    switch ($op) {
        "1" { OtimizacaoSistema }
        "2" { OtimizacaoRede }
        "3" { OtimizacaoInicializacao }
        "0" { exit }
        default { Write-Host "Opção inválida!"; Pause }
    }
}
